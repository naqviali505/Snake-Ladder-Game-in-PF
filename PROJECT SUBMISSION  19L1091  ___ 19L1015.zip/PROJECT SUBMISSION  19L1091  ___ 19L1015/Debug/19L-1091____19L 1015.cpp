#include "graphics.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include<iostream>
#include<stdlib.h>
#include<stdio.h>
using namespace std;
int temp = 0;
int count = 0, count1 = 0, dice = 0, temp2 = 0, dice2 = 0, count2 = 0;
int k = 0;
int error = 0;
int x1 = 40, y1 = 550, x2 = 20, y2 = 550;
char space;
void board();
void values();
void dicef();
void dicef2();
void player1turn();
void player2turn();
void position1();
void position2();
int main()
{
	initwindow(1000, 1200);

	board();
	values();
	settextstyle(6, HORIZ_DIR, 1);
	outtextxy(800, 400, "PRESS a TO ROLL DICE");
	settextstyle(0, HORIZ_DIR, 1);

	while (count1 != 1)

	{
		if (k == 0)
		{

			dicef();
			position1();
			settextstyle(6, HORIZ_DIR, 1);
			outtextxy(800, 400, "PRESS a TO ROLL DICE");
			settextstyle(0, HORIZ_DIR, 1);
			setcolor(BLUE);
			circle(x2, y2, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(x2, y2, BLUE);
		}
		else if (k == 1)
		{
			dicef2();
			position2();
			settextstyle(6, HORIZ_DIR, 1);
			outtextxy(800, 400, "PRESS a TO ROLL DICE");
			settextstyle(0, HORIZ_DIR, 1);
			setcolor(RED);
			circle(x1, y1, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(x1, y1, RED);
		}

	}
	getch();

	return 0;

}
void board()
{
	setcolor(WHITE);
	settextstyle(10, HORIZ_DIR, 5);
	outtextxy(100, 30, " THE SNAKE AND LADDER GAME ");
	settextstyle(0, HORIZ_DIR, 1);
	//FOR BOARD
	setcolor(BLUE);
	rectangle(100, 100, 700, 600);
	setfillstyle(1, YELLOW);
	floodfill(200, 500, BLUE);
	setlinestyle(0, 1, 3);
	line(200, 100, 200, 600);
	line(300, 100, 300, 600);
	line(400, 100, 400, 600);
	line(500, 100, 500, 600);
	line(600, 100, 600, 600);
	line(100, 200, 700, 200);
	line(100, 300, 700, 300);
	line(100, 400, 700, 400);
	line(100, 500, 700, 500);
	line(100, 600, 700, 600);
	setlinestyle(0, 1, 3);
	//
	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(110, 110, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 12);
	floodfill(310, 110, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(510, 110, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(210, 210, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 12);
	floodfill(410, 210, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 12);
	floodfill(610, 210, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(110, 310, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(310, 310, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 12);
	floodfill(510, 310, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(210, 410, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(410, 410, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(610, 410, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(110, 510, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(310, 510, BLUE);

	setcolor(BLUE);
	setfillstyle(1, 3);
	floodfill(510, 510, BLUE);







	//FOR SNAKES
	setcolor(BROWN);
	circle(350, 150, 20);
	circle(330, 170, 20);
	circle(330, 190, 20);
	circle(350, 210, 20);
	circle(370, 230, 20);
	circle(350, 250, 20);
	circle(330, 270, 20);
	circle(310, 290, 20);
	circle(290, 310, 20);
	circle(270, 330, 20);
	circle(260, 350, 20);
	circle(240, 370, 20);
	circle(240, 400, 20);
	circle(210, 420, 20);
	circle(190, 440, 20);
	circle(170, 470, 20);
	circle(150, 500, 20);
	circle(350, 150, 20);
	///////////////////////////////////////

	circle(450, 250, 20);
	circle(430, 270, 20);
	circle(450, 290, 20);
	circle(430, 310, 20);
	circle(435, 330, 20);
	circle(430, 350, 20);
	circle(450, 370, 20);
	circle(450, 390, 20);
	circle(430, 410, 20);
	////////////////////////////////////////

	circle(550, 350, 20);
	circle(550, 370, 20);
	circle(530, 390, 20);
	circle(510, 410, 20);
	circle(490, 430, 20);
	circle(470, 460, 20);
	circle(460, 484, 20);
	circle(450, 509, 20);
	circle(430, 530, 20);
	/////////////////////////////////////////////// 

	circle(670, 250, 20);
	circle(660, 270, 20);
	circle(650, 290, 20);
	circle(640, 310, 20);
	circle(620, 330, 20);
	circle(630, 360, 20);
	circle(620, 390, 20);
	circle(625, 410, 20);

	//ladders
	setcolor(GREEN);
	line(230, 150, 230, 450);
	line(250, 150, 250, 450);
	line(230, 170, 250, 170);
	line(233, 270, 250, 270);
	line(230, 410, 250, 410);
	line(230, 270, 250, 270);
	line(230, 320, 250, 320);
	line(230, 350, 250, 350);
	//second laddder
	line(330, 270, 330, 570);
	line(350, 270, 350, 570);
	line(330, 280, 350, 280);
	line(330, 310, 350, 310);
	line(330, 350, 350, 350);
	line(330, 390, 350, 390);
	line(330, 430, 350, 430);
	line(330, 480, 350, 480);
	//third ladder
	line(530, 470, 530, 570);
	line(550, 470, 550, 570);
	line(530, 490, 550, 490);
	line(530, 530, 550, 530);
	line(530, 560, 550, 560);
	//fourth ladder
	line(530, 140, 530, 240);
	line(550, 140, 550, 240);
	line(530, 160, 550, 160);
	line(530, 190, 550, 190);
	line(530, 230, 550, 230);
	//players indications
	setcolor(RED);
	circle(100, 700, 35);
	setfillstyle(1, GREEN);
	floodfill(120, 700, RED);
	settextstyle(6, HORIZ_DIR, 1);
	setcolor(GREEN);
	outtextxy(80, 640, "player 1");
	setcolor(BLUE);
	circle(180, 700, 35);
	setfillstyle(1, RED);
	floodfill(180, 700, BLUE);
	setcolor(RED);
	outtextxy(180, 640, "player 2");
	settextstyle(0, HORIZ_DIR, 1);

}
void values()
{
	setcolor(BLUE);

	outtextxy(150, 540, "1");
	outtextxy(250, 540, "2");
	outtextxy(350, 540, "3");
	outtextxy(450, 540, "4");
	outtextxy(550, 540, "5");
	outtextxy(650, 540, "6");

	outtextxy(150, 440, "12");
	outtextxy(250, 440, "11");
	outtextxy(350, 440, "10");
	outtextxy(450, 440, "9");
	outtextxy(550, 440, "8");
	outtextxy(650, 440, "7");
	outtextxy(150, 340, "13");
	outtextxy(250, 340, "14");
	outtextxy(350, 340, "15");
	outtextxy(450, 340, "16");
	outtextxy(550, 340, "17");
	outtextxy(650, 340, "18");
	outtextxy(150, 240, "24");
	outtextxy(250, 240, "23");
	outtextxy(350, 240, "22");
	outtextxy(450, 240, "21");
	outtextxy(550, 240, "20");
	outtextxy(650, 240, "19");
	outtextxy(150, 140, "30");
	outtextxy(250, 140, "29");
	outtextxy(350, 140, "28");
	outtextxy(450, 140, "27");
	outtextxy(550, 140, "26");
	outtextxy(650, 140, "25");


}
void dicef()
{

	int rand();

	srand(time(NULL));
	char play;
	play = getch();
	count = 0;
	while (count != 1)
	{


		if (play == 'a')
		{

			dice = (rand() % 6) + 1; //get random number
			if (temp + dice <= 30)
			{
				temp = temp + dice;
			}
			else
			{
				outtextxy(820, 420, "sorry try harder to win");
			}
			count = 1;
		}
		else
		{
			play = getch();
		}
	}
}
void dicef2()
{

	int rand();

	srand(time(NULL));
	char play1;
	play1 = getch();
	count2 = 0;
	while (count2 != 1)
	{


		if (play1 == 'a')
		{

			dice2 = (rand() % 6) + 1; //get random number
			if (temp2 + dice2 <= 30)
			{
				temp2 = temp2 + dice2;
			}
			else
			{
				setcolor(BLUE);
				outtextxy(820, 420, "soory try harder to win");
			}
			count2 = 1;
		}
		else
		{
			play1 = getch();
		}
	}
}
void player1turn()
{
	setcolor(GREEN);
	rectangle(800, 300, 1100, 400);
	settextstyle(6, HORIZ_DIR, 2);
	outtextxy(820, 350, "dice=");

	char arr[50];
	sprintf(arr, "%d", dice);
	outtextxy(890, 350, arr);
	outtextxy(800, 250, "player1 turns");
	settextstyle(0, HORIZ_DIR, 1);
}
void player2turn()
{
	setcolor(RED);
	rectangle(800, 300, 1100, 400);
	settextstyle(8, HORIZ_DIR, 2);
	outtextxy(820, 350, "dice=");
	char arr2[50];
	sprintf(arr2, "%d", dice2);
	outtextxy(890, 350, arr2);
	outtextxy(800, 250, "player2 turns");
	settextstyle(0, HORIZ_DIR, 1);

}
void position2()
{
	if (temp2 != 3 && temp2 != 5 && temp2 != 11 && temp2 != 17 && temp2 != 19 && temp2 != 20 && temp2 != 21 && temp2 != 27)
	{

		if (temp2 == 1)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(150, 548, 25);

			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 530, BLUE);
			x2 = 150;
			y2 = 548;
		}
		else		if (temp2 == 2)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(250, 548, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(250, 530, BLUE);
			x2 = 250;
			y2 = 548;
		}

		else	if (temp2 == 4)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(450, 548, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 530, BLUE);
			x2 = 450;
			y2 = 548;
		}

		else	if (temp2 == 6)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(650, 548, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(650, 538, BLUE);
			x2 = 650;
			y2 = 548;
		}
		else	if (temp2 == 7)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(650, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(650, 438, BLUE);
			x2 = 650;
			y2 = 458;
		}

		else	if (temp2 == 8)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(550, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(550, 438, BLUE);
			x2 = 550;
			y2 = 458;
		}
		else	if (temp2 == 9)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(450, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 438, BLUE);
			x2 = 450;
			y2 = 458;
		}
		else	if (temp2 == 10)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(350, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(350, 438, BLUE);
			x2 = 350;
			y2 = 458;
		}

		else	if (temp2 == 12)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(150, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 438, BLUE);
			x2 = 150;
			y2 = 458;
		}
		else	if (temp2 == 13)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(150, 358, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 338, BLUE);
			x2 = 150;
			y2 = 358;
		}

		else	if (temp2 == 14)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(250, 358, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(250, 338, BLUE);
			x2 = 250;
			y2 = 358;
		}

		else	if (temp2 == 15)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(350, 358, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(350, 338, BLUE);
			x2 = 350;
			y2 = 358;
		}

		else	if (temp2 == 16)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(450, 358, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 338, BLUE);
			x2 = 450;
			y2 = 358;
		}
		else	if (temp2 == 18)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(650, 358, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(650, 338, BLUE);
			x2 = 650;
			y2 = 358;
		}

		else	if (temp2 == 22)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(350, 258, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(350, 238, BLUE);
			x2 = 350;
			y2 = 258;
		}
		else	if (temp2 == 23)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(250, 258, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(250, 238, BLUE);
			x2 = 250;
			y2 = 258;
		}
		else	if (temp2 == 24)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(150, 258, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 238, BLUE);
			x2 = 150;
			y2 = 258;
		}
		else	if (temp2 == 25)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(150, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 138, BLUE);
			x2 = 150;
			y2 = 158;
		}
		else	if (temp2 == 26)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(250, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(250, 138, BLUE);
			x2 = 250;
			y2 = 158;
		}
		else	if (temp2 == 28)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(450, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 138, BLUE);
			x2 = 450;
			y2 = 158;
		}
		else	if (temp2 == 29)
		{
			cleardevice();
			board();
			values();
			player2turn();

			setcolor(BLUE);
			circle(550, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(550, 138, BLUE);
			x2 = 550;
			y2 = 158;
		}
		else	if (temp2 == 30)
		{
			cleardevice();
			board();
			values();
			player2turn();
			setcolor(BLUE);
			circle(650, 150, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(650, 138, BLUE);
			x2 = 650;
			y2 = 150;
			settextstyle(6, HORIZ_DIR, 2);
			outtextxy(820, 200, "<<<<<<<player 2 is winner>>>>>>>>>");
			settextstyle(0, HORIZ_DIR, 2);
			count1 = 1;
		}
	}
	else
	{
		if (temp2 == 3)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "horray!! its a ladder");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();
			setcolor(BLUE);
			circle(350, 258, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(350, 238, BLUE);
			temp2 = 22;
			x2 = 350;
			y2 = 258;
		}
		else if (temp2 == 5)
		{

			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "horray!! its a ladder");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(550, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(550, 438, BLUE);
			x2 = 550;
			y2 = 458;
			temp2 = 8;
		}
		else if (temp2 == 11)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "horray!! its a ladder");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(250, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(250, 138, BLUE);
			temp2 = 26;
			x2 = 250;
			y2 = 158;
		}
		else if (temp2 == 17)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A SNAKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();
			setcolor(BLUE);
			circle(450, 548, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 538, BLUE);
			temp2 = 4;
			x2 = 450;
			y2 = 558;
		}
		else if (temp2 == 19)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A SNAKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(650, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(650, 438, BLUE);
			temp2 = 7;
			x2 = 650;
			y2 = 458;
		}
		else if (temp2 == 20)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A LADDER");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(550, 158, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(550, 138, BLUE);
			temp2 = 29;
			x2 = 550;
			y2 = 158;
		}
		else if (temp2 == 21)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A SNAKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(450, 458, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(450, 438, BLUE);
			temp2 = 9;
			x2 = 450;
			y2 = 458;
		}
		else if (temp2 = 27)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A SNAKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player2turn();

			setcolor(BLUE);
			circle(150, 548, 25);
			setfillstyle(SOLID_FILL, RED);
			floodfill(150, 538, BLUE);
			temp2 = 1;
			x2 = 150;
			y2 = 548;
		}


	}
	k = 0;
}
void position1()
{
	if (temp != 3 && temp != 5 && temp != 11 && temp != 17 && temp != 19 && temp != 20 && temp != 21 && temp != 27)
	{
		if (temp == 1)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(150, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 530, RED);
			x1 = 150;
			y1 = 540;
		}
		else		if (temp == 2)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(250, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(250, 530, RED);
			x1 = 250;
			y1 = 540;
		}

		else	if (temp == 4)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(450, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 530, RED);
			x1 = 450;
			y1 = 540;
		}

		else	if (temp == 6)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(650, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(650, 530, RED);
			x1 = 650;
			y1 = 540;
		}
		else	if (temp == 7)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(650, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(650, 430, RED);
			x1 = 650;
			y1 = 550;
		}

		else	if (temp == 8)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//  position2();
			setcolor(RED);
			circle(550, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(550, 430, RED);
			x1 = 550;
			y1 = 450;
		}
		else	if (temp == 9)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(450, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 430, RED);
			x1 = 450;
			y1 = 450;
		}
		else	if (temp == 10)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//  position2();
			setcolor(RED);
			circle(350, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(350, 430, RED);
			x1 = 350;
			y1 = 450;
		}

		else	if (temp == 12)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(150, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 430, RED);
			x1 = 150;
			y1 = 450;
		}
		else	if (temp == 13)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(150, 350, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 330, RED);
			x1 = 150;
			y1 = 350;
		}

		else	if (temp == 14)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(250, 350, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(250, 330, RED);
			x1 = 250;
			y1 = 350;
		}

		else	if (temp == 15)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(350, 350, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(350, 330, RED);
			x1 = 350;
			y1 = 350;
		}

		else	if (temp == 16)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(450, 350, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 330, RED);
			x1 = 450;
			y1 = 350;
		}
		else	if (temp == 18)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(650, 350, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(650, 330, RED);
			x1 = 650;
			y1 = 350;
		}

		else	if (temp == 22)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(350, 250, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(350, 230, RED);
			x1 = 350;
			y1 = 250;
		}
		else	if (temp == 23)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(250, 250, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(250, 230, RED);
			x1 = 250;
			y1 = 250;
		}
		else	if (temp == 24)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(150, 250, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 230, RED);
			x1 = 150;
			y1 = 250;
		}
		else	if (temp == 25)
		{
			cleardevice();
			board();
			values();
			player1turn();
			// position2();
			setcolor(RED);
			circle(150, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 130, RED);
			x1 = 150;
			y1 = 150;
		}
		else	if (temp == 26)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//  position2();
			setcolor(RED);
			circle(250, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(250, 130, RED);
			x1 = 250;
			y1 = 150;
		}
		else	if (temp == 28)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(450, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 130, RED);
			x1 = 450;
			y1 = 150;
		}
		else	if (temp == 29)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//  position2();
			setcolor(RED);
			circle(550, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(550, 130, RED);
			x1 = 550;
			y1 = 150;
		}
		else	if (temp == 30)
		{
			cleardevice();
			board();
			values();
			player1turn();
			//position2();
			setcolor(RED);
			circle(650, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(650, 130, RED);
			x1 = 650;
			y1 = 150;
			settextstyle(6, HORIZ_DIR, 2);
			outtextxy(820, 200, "<<<<<<<<player 1 is winner>>>>>>>>>");
			settextstyle(0, HORIZ_DIR, 1);
			count1 = 1;
		}
	}
	else
	{
		if (temp == 3)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS ladder");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			// position2();
			setcolor(RED);
			circle(350, 250, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(350, 230, RED);
			temp = 22;
			x1 = 350;
			y1 = 250;
		}
		else if (temp == 5)
		{

			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS ladder");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//  position2();
			setcolor(RED);
			circle(550, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(550, 430, RED);
			temp = 8;
			x1 = 550;
			y1 = 450;
		}
		else if (temp == 11)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS LADDER");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//position2();
			setcolor(RED);
			circle(250, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(250, 130, RED);
			temp = 26;
			x1 = 250;
			y1 = 150;
		}
		else if (temp == 17)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS SNAKKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//position2();
			setcolor(RED);
			circle(450, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 530, RED);
			temp = 4;
			x1 = 450;
			y1 = 540;
		}
		else if (temp == 19)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS SNAKKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//position2();
			setcolor(RED);
			circle(650, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(650, 430, RED);
			temp = 7;
			x1 = 650;
			y1 = 450;
		}
		else if (temp == 20)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS A LADDER");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//  position2();
			setcolor(RED);
			circle(550, 150, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(550, 130, RED);
			temp = 29;
			x1 = 550;
			y1 = 150;
		}
		else if (temp == 21)
		{
			cleardevice();
			board();
			values();
			player1turn();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS SNAKKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			//position2();
			setcolor(RED);
			circle(450, 450, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(450, 430, RED);
			temp = 9;
			x1 = 450;
			y1 = 450;
		}
		else if (temp = 27)
		{
			cleardevice();
			board();
			values();
			settextstyle(5, HORIZ_DIR, 2);
			outtextxy(820, 220, "ITS SNAKKE BITE");
			settextstyle(0, HORIZ_DIR, 1);
			player1turn();
			//position2();
			setcolor(RED);
			circle(150, 540, 25);
			setfillstyle(SOLID_FILL, GREEN);
			floodfill(150, 530, RED);
			temp = 1;
			x1 = 150;
			y1 = 540;
		}


	}
	k = 1;
}









/////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////




/////////////////////////////////////////
//////////////////////////////////////////
/////////////////////////////////////////


